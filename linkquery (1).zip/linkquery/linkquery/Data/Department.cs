﻿using System.ComponentModel.DataAnnotations;

namespace linkquery.Data
{
    public class Department
    {
        [Key]
        public int Id { get; set; }
    }
}
